//
//  ViewController.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by moxDroid on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    : C0689095
//  Name        : Navjot Kaur

import UIKit
import MessageUI

class SMSAndPhoneCallViewController: UIViewController , MFMessageComposeViewControllerDelegate

   {
    
    //Sending SMS
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult)
    {
        self.dismiss(animated: true, completion: nil)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
   //Sending SMS
    
    @IBAction func sendmsg(_ sender: UIButton) {
        
        if (MFMessageComposeViewController.canSendText()) {
            let Message = MFMessageComposeViewController()
            Message.body = "Message Body"
            Message.recipients = ["Recipient Body"]
            Message.messageComposeDelegate = self
            self.present(Message, animated: true, completion: nil)
            
            print("hello")
        }
    }
    
    
    @IBAction func phonecall(_ sender: UIButton) {
        
        if let url = URL(string: "tel:// +14168225631"),
            UIApplication.shared.canOpenURL(url)
        {
            if #available(iOS 10, *)
            {
                UIApplication.shared.open(url)
            } else
            {
                UIApplication.shared.openURL(url)
            }
        }
        
    }
    

}

