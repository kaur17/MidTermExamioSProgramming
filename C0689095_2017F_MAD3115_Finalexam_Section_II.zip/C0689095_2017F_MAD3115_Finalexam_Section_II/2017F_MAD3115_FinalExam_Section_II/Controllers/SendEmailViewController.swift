//
//  SendEmailViewController.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by moxDroid on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    :  C0689095
//  Name        : Navjot Kaur

import UIKit
import MessageUI

class SendEmailViewController: UIViewController , MFMailComposeViewControllerDelegate {

    @IBOutlet weak var subject: UITextField!
    @IBOutlet weak var body: UITextView!
    @IBOutlet weak var sendmail: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
   
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

       @IBAction func sendmail(_ sender: UIButton) {
        if MFMailComposeViewController.canSendMail(){
            
    
        var picker = MFMailComposeViewController()
        picker.mailComposeDelegate = self
        picker.setSubject(subject.text!)
        picker.setMessageBody(body.text, isHTML: true)
        
           self.present(picker, animated: true, completion: nil)
        }
        
    
}
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?)
    {
        dismiss(animated: true, completion: nil)
    }
    
    
    
    
}





