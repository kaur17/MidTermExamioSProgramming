//
//  ShowLocationOnMapViewController.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by moxDroid on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    :  C0689095
//  Name        : Navjot Kaur

import UIKit
import MapKit

class ShowLocationOnMapViewController: UIViewController, MKMapViewDelegate {
   
    let locationManager = CLLocationManager()

    var latitude: Double!
    var longitude: Double!
    
    @IBOutlet weak var mymap: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self as! CLLocationManagerDelegate
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestLocation()
        locationManager.startUpdatingLocation()

        // Do any additional setup after loading the view.
        
     
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ShowLocationOnMapViewController: CLLocationManagerDelegate {

    private func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {

        if status == .authorizedWhenInUse {


            locationManager.startUpdatingLocation()

            
//            mymap.myLocationEnabled = true
//            mymap.settings.myLocationButton = true
        }
    }


    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        if let location = locations.first {


//            mymap.camera = GMSCameraPosition(target: location.coordinate, zoom: 15, bearing: 0, viewingAngle: 0)


            //locationManager.stopUpdatingLocation()


        let location:CLLocation = locations.last!
        self.latitude = location.coordinate.latitude
        self.longitude = location.coordinate.longitude


    }


 func locationManager(manager: CLLocationManager,didFailWithError error: Error)
    {

        print("An error occurred while tracking location changes")
    }


}
}



